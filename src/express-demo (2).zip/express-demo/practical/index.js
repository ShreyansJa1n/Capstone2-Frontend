var express= require('express')
var app= express()
var ExpressFormidable = require('express-formidable')
var moment = require("moment")
var Student = require('./models')
app.use(express.json())
var mongoose = require('mongoose')
app.set("view engine","pug")
app.set("views","./views")

mongoose.connect(
    "mongodb+srv://crudexample:crudpassword@cluster0.3hwst.mongodb.net/CRUDPrac?retryWrites=true&w=majority"
  );
  

app.use(ExpressFormidable({
    keepExtensions: true,
    uploadDir:__dirname+"/uploads/"
}))

app.get('/',function(req,res){
    res.render("index", {courses:[], cgpa:false, gender:"Male"})
})

app.post('/',function(req,res){

    if (req.fields.button === "Create"){

        var object = {
            name:req.fields.name,
            address:req.fields.address,
            no:req.fields.no,
            gender: req.fields.gender,
            courses: req.fields.courses,
            dob: req.fields.dob,
            cgpa: req.fields.cgpa,
            pcgpa: req.fields.pcgpa,
            image: req.files.file.path===undefined ? '' : req.files.file.path
        }

        Student.create(object,function(err,obj){
            if (!obj || err){
                res.send("Error" + err)
            }
            else{
                res.render("index" ,{ obj1: obj.id, courses:[], gender:"Male", message:"Created"})
            }
        })
    }

    if (req.fields.button === "Read"){
        var id= req.fields.id
        Student.findById(id, function(err, obj){
            if (!obj || err){
                res.send("Error" + err)
            }
            else{
                console.log(obj)
                res.render("index" ,{ obj1: obj.id, name: obj.name, address: obj.address, no:obj.no, gender:obj.gender, courses:obj.courses, dob:moment(obj.dob).format('YYYY-MM-DD'), cgpa:obj.cgpa,pcgpa:obj.pcgpa,image:obj.image, image:obj.image, message:"Read"})
            }
        })
    }
    if (req.fields.button === "Update"){
        var id= req.fields.id
        Student.findByIdAndUpdate(id, req.fields, function(err, obj){
            if (!obj || err){
                res.send("Error" + err)
            }
            else{
                console.log(obj)
                res.render("index" ,{courses:[], cgpa:false, gender:"Male", message:"Updated"})
            }
        })
    }
    if (req.fields.button === "Delete"){
        var id= req.fields.id
        Student.findByIdAndDelete(id, function(err, obj){
            if (!obj || err){
                res.send("Error" + err)
            }
            else{
                console.log(obj)
                res.render("index" ,{courses:[], cgpa:false, gender:"Male", message:"Deleted"})
            }
        })
    }

    // console.log(req.fields)
    // console.log(req.body)
    // res.send('ok')
})

app.get('/uploads',function(req,res){
    res.sendFile('/'+req.query.id)
})

app.listen(8000,function(){
    console.log('Started')
})