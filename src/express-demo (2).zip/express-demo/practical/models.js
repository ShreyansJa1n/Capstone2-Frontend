const mongoose = require('mongoose')

const Student = mongoose.Schema({
    name: {type: String, required: true},
    address: String,
    no: {type:Number , required: true},
    gender: String,
    courses: Array,
    dob: Date,
    cgpa: Boolean,
    pcgpa: Number,
    image: String
})

module.exports = mongoose.model('StudentDB',Student)